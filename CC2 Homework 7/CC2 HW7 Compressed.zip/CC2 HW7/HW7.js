var animation = [];
var runAnimation = [];
var i = 0;
var f;
var myCharacter;
var characterX = 100;
var characterY = 100;
var speed = 5;
var idleStrings;
var runStrings;
var flipX = false;
var myFood;
var foodArray = [];
var badFoodArray = [];
var foodAmount = 5;
var score = 0;
var gameTime = 30; //in seconds
var winTextX = 0;
var winTextY = 0;
var lossTextX = 0;
var lossTextY = 0;
var bgSound;
var badSound;
var goodSound;

//loads character images
function preload()
{
    soundFormats('mp3', 'ogg', 'wav');
    bgSound = loadSound("Assets/Sounds/looping-hiphop-beat.wav");
    badSound = loadSound("Assets/Sounds/badFood.mp3");
    goodSound = loadSound("Assets/Sounds/biting-apple.mp3");
    idleStrings = loadStrings("Assets/idle.txt");
    runStrings = loadStrings("Assets/run.txt");
}

function setup()
{
    let myCanvas = createCanvas(1480,725);
    //update index used for character animation
    setInterval(updateIndex, 50);
    setTimeout(gameEnd, gameTime*1000);
    setInterval(countdown, 1000);
    setInterval(randomizeFood, 5000);

    // passes info into character class
    for (let i = 0; i < idleStrings.length; i++) 
    {
        myCharacter = new character(idleStrings[i], characterX, characterY); 
        animation.push(myCharacter);
    
        myCharacter = new character(runStrings[i], characterX, characterY); 
        runAnimation.push(myCharacter);
    }

    //passes info into food class
    for (var f = 0; f < foodAmount; f++) 
        {
            myFood = new food(random(100, 1380), random(100, 625),random(50,200),random(50,200),random(50,200));
            foodArray.push(myFood);

            //bad food
            myFood = new food(random(100,1380), random(100,625), 50,50,50);
            badFoodArray.push(myFood);
        }

    myCanvas.mousePressed(playBackgroundSound);
}

function draw()
{
    background(0);
    displayFood();
    displayBadFood();
    moveCharacter();
    collision();
    displayScoreText();
    displayCountdown();
    displayWinLose();
}

function updateIndex()
{
    i++;
    if(i > 14)
    {
        i = 0;
    }  
}

//called in draw
function displayFood()
{
    //draws the food
    for (let f = 0; f < foodArray.length; f++) 
    {
        foodArray[f].draw();
    }
}

//called in draw
function displayBadFood()
{
    //draws the food
    for (let b = 0; b < badFoodArray.length; b++) 
    {
        badFoodArray[b].draw();
    }
}

//called in draw
function moveCharacter()
{
//character movement 
    if (keyIsPressed) 
    {
        runAnimation[i].draw();
        if (key == "a") {
            flipX = true
            characterX-= speed;
        }
        if (key == "d") {
            flipX = false
            characterX+= speed;
        }
        if (key == "w") {
            characterY-= speed;
        }
        if (key == "s") {
            characterY+= speed;
        }

        for (let i = 0; i < idleStrings.length; i++) 
        {
            animation[i].flipX = flipX;
            animation[i].x = characterX;
            animation[i].y = characterY;
            runAnimation[i].flipX = flipX;
            runAnimation[i].x = characterX;
            runAnimation[i].y = characterY;
        }
    }
    else {
        animation[i].draw();
    }
}

//called in draw
function collision()
{

    for (let f = 0; f < foodArray.length; f++)
        {
            if (collideRectRect(animation[i].x, animation[i].y, animation[i].imageWidth - 100, animation[i].imageHeight,foodArray[f].x, foodArray[f].y, 25, 25)) {
                foodArray.splice(f, 1);
                score ++;
                goodSound.play();
            }
        }

        for (let b = 0; b < badFoodArray.length; b++)
        {
            if (collideRectRect(animation[i].x, animation[i].y, animation[i].imageWidth - 100, animation[i].imageHeight,badFoodArray[b].x, badFoodArray[b].y, 25, 25)) {
                badFoodArray.splice(b,1);
                score --;
                badSound.play();
            }
        }
}

function randomizeFood()
{
    for (var f = 0; f < foodArray.length; f++) 
        {
            foodArray[f].x = random(50,1430);
            foodArray[f].y = random(50,680);
        }

    for (var b = 0; b < badFoodArray.length; b++) 
        {
            badFoodArray[b].x = random(50,1430);
            badFoodArray[b].y = random(50,680);
        }
}

//called in draw
function displayScoreText()
{
    fill(255,255,255);
    textSize(30);
    text('Score:' + score, 10, 30);
}

function countdown()
{
        gameTime -=1;    
}

//called in draw
function displayCountdown()
{
    fill(255,255,255);
    textSize(30);
    text('Time Left:' + gameTime + 's', 1280, 30);
}

function gameEnd()
{
    winTextX = 700;
    winTextY = 300;
    lossTextX = 700;
    lossTextY = 300;
    characterX = 2000;
    characterY = 2000;
}

//called in draw
function displayWinLose()
{
    if(score < foodAmount)
    {
        fill(255,255,255);
        textSize(30);
        text('Loss',lossTextX,lossTextY);
    } 
    else 
    {
        fill(255,255,255);
        textSize(30);
        text('Win',winTextX,winTextY); 
    }

    if(score >= foodAmount)
    {
        fill(255,255,255);
        textSize(30);
        text('Win',winTextX,winTextY);
        winTextX = 700;
        winTextY = 300;
    }
}

function playBackgroundSound()
{
    bgSound.play();
}