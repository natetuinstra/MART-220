class obstacle
{
    constructor(x,y,diameter,r,g,b,randomX,randomY){
        this.x = x;
        this.y = y;
        this.diam = diameter;
        this.r = r;
        this.g = g;
        this.b = b;
        this.rX = randomX;
        this.rY = randomY;
    }

    draw(){
        //movement
        var moveX = this.rX;
        var moveY = this.rY;
        this.x += moveX;
        this.y += moveY;

        //wall collision
        if(this.x - this.diam/2 <= 0){
            this.rX *= -1;
        }
        if(this.x + this.diam/2 >= 1480){
            this.rX *=-1;
        }
        if(this.y - this.diam/2 <= 0){
            this.rY *= -1;
        }
        if(this.y + this.diam/2 >= 725){
            this.rY *=-1;
        }

        //object
        fill(this.r, this.g, this.b);
        circle(this.x, this.y, this.diam);
    }

    isColliding(){
        this.r += 25;
        this.g += 25;
        this.b += 25;
    }
}