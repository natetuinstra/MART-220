//player variables
var playerx = 50;
var playery = 50;
var playerDiameter = 50;
var playerSpeed = 5;

//obstacle variables
var obstacleArray = [];
var obstacleAmount = 10;
var myObstacle;
var obstacleDiameter = 50;

//win text variables
var winx = -50;
var winy = -50;

//game vars
var game = 0;
var gameText = 0;

var score = 0;
var time = 0;
var myTimer;

function setup()
{
    createCanvas(1480,725);

    //keeps track of time by calling function "timer"
    myTimer = setInterval(timer, 1000);

 //passes info into obstacle class
 for (let o = 0; o < obstacleAmount; o++) 
    {
        myObstacle = new obstacle(740, 362.5, obstacleDiameter, 0, 0, 0, random(-5,5), random(-5,5));
        obstacleArray.push(myObstacle);
    }
}

function draw()
{
background(255);
noStroke();

border(50,50,50, 0,0,1480,20, 1460,0,20,725, 0,705,1480,20, 0,0,20,715);
displayObstacles();
player(255,255,255,playerx,playery,playerDiameter);
playerMove(83,65,87,68,playerSpeed);
collision();
winDetection();
displayWin(50,winx,winy);

    //game start screen
    if(game == 0){
        gameText=0;
        time=0;
        playerx = -100;
        playery = -100;
        fill(50,50,50);
        rect(gameText + 0,gameText + 0,1480,725);
        fill(255);
        text('GHOST BALL',gameText + 555,gameText + 100);
        textSize(35);
        text('Move your invisible ball over the other balls to turn them white as quickly as possible.',gameText + 100,gameText + 200);
        text('You can locate yourself if you go over the gray border.',gameText + 320,gameText + 300);
        text('Press ENTER to begin.',gameText + 540,gameText + 400);
        
    }
    else(game > 0);
        gameText=1481;

    if(keyIsDown(13)){
        game +=1;
        playerx = 50;
        playery = 50;
    }
}

function timer(){
    time ++;
}

function border(red,green,blue,x1,y1,length1,width1,x2,y2,length2,width2,x3,y3,length3,width3,x4,y4,length4,width4){
fill(red,green,blue);
rect(x1,y1,length1,width1);
rect(x2,y2,length2,width2);
rect(x3,y3,length3,width3);
rect(x4,y4,length4,width4);
}

function displayObstacles(){
    for (let o = 0; o < obstacleAmount; o++){
        obstacleArray[o].draw();
    }
}

function player(red,green,blue,x,y,diameter){
    fill(red,green,blue);
    circle(x,y,diameter);
}

function playerMove(w,a,s,d,speed){
    if (keyIsDown(a)) {
        playerx -= speed;
      } else if (keyIsDown(d)) {
        playerx += speed;
      }

      if (keyIsDown(s)) {
        playery -= speed;
      } else if (keyIsDown(w)) {
        playery += speed;
      }
}

function collision(){
    for(let o = 0; o < obstacleAmount; o++){
        if(playerx + playerDiameter/2 >= obstacleArray[o].x - obstacleArray[o].diam/2 && playerx - playerDiameter/2 <= obstacleArray[o].x + obstacleArray[o].diam/2 && playery + playerDiameter/2 >= obstacleArray[o].y - obstacleArray[o].diam/2 && playery - playerDiameter/2 <= obstacleArray[o].y + obstacleArray[o].diam/2){
            obstacleArray[o].isColliding();
        }
    }
}

function winDetection(){
    for(let o = 0; o < obstacleAmount; o++){
        if (obstacleArray[o].r >= 255 && obstacleArray[o].g >= 255 && obstacleArray[o].b >= 255){
            obstacleArray[o].r = 0;
            obstacleArray[o].x = -100;
            obstacleArray[o].y = -100;
            score += 1;
        }
        if (score >= obstacleAmount){
            clearInterval(myTimer);
            winx = 610
            winy = 362.5
        }
    }
}

function displayWin(size,x,y){
    textSize(size);
    fill(0);
    textSize(50);
    text("Time:" + time + "s",x,y);
}

