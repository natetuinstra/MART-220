var characterX = window.innerWidth/2;
var characterY = window.innerHeight/2;

var idleStrings;
var runStrings;

var angle = 0;

function preload(){
    idleStrings = loadStrings("Assets/idle.txt");
    runStrings = loadStrings("Assets/run.txt");
}

function setup(){
    createCanvas(windowWidth, windowHeight);

    myAnimation = new character(characterX, characterY);
    myAnimation.loadAnimation('idle', idleStrings);
    myAnimation.loadAnimation('run', runStrings);
}

function draw(){
    background(29,0,51);
    
    moveCharacter();
}

function moveCharacter(){
    if (kb.pressing('d')) {
        myAnimation.updatePosition('d');
        myAnimation.draw('run');
    }
    if (kb.pressing('a')) {
        myAnimation.updatePosition('a');
        myAnimation.draw('run');
    }
    if (kb.pressing('w')) {
        myAnimation.updatePosition('w');
        myAnimation.draw('run');
        myAnimation.speedMore();
    }
    else {
        myAnimation.updatePosition('stopped');
        myAnimation.draw('idle');
        myAnimation.speedLess();
    }

    //drift
    if (kb.pressing('shift')) {
        myAnimation.turnMore();
    }
    else {
        myAnimation.turnLess();

    //brake
    }
    if (kb.pressing('space')) {
        myAnimation.speedLess();
        myAnimation.speed -=.1;
    }
}