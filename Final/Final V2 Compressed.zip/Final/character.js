class character
{
  constructor(x,y)
  {
    this.x = x;
    this.y = y;
    
    this.speed = 0;
    this.angle = 270;
    this.turnRadius = 3; //higher numbers equal a sharper turn
    this.currentAnimation;
    this.createAnimation();
  }

  createAnimation() 
  {
    this.currentAnimation = createSprite(this.x, this.y);
  }

  loadAnimation(animationType, fileNames) 
  {
    this.currentAnimation.addAnimation(animationType, fileNames[0], fileNames[fileNames.length - 1]);
    //hit box
    this.currentAnimation.width = 200;
    this.currentAnimation.height = 400;
  }

  draw(animationType)
  {
    this.currentAnimation.frameDelay = 5;
    this.currentAnimation.scale = .5;
    this.currentAnimation.changeAnimation(animationType);
    this.currentAnimation.rotationLock = true;
    this.currentAnimation.image.offset.y = 50;

    if (animationType == 'run' && this.direction == 'd') {
      this.angle += this.turnRadius;
      this.currentAnimation.direction = this.angle;
      this.currentAnimation.speed = this.speed;
      this.currentAnimation.rotateTo(this.angle-270,100); //visually rotate image to angle
    }
    else if (animationType == 'run' && this.direction == 'a') {
      this.angle -= this.turnRadius;
      this.currentAnimation.direction = this.angle;
      this.currentAnimation.speed = this.speed
      this.currentAnimation.rotateTo(this.angle-270,-100); //visually rotate image to angle
    }
    else if (animationType == 'run' && this.direction == 'w') {
      this.currentAnimation.direction = this.angle;
      this.currentAnimation.speed = this.speed;
    }
    else if (animationType == 'idle' && this.direction == 'stopped') {
      this.currentAnimation.speed = this.speed;
    }
    else {
      this.currentAnimation.velocity.x = 0;
      this.currentAnimation.velocity.y = 0;
    }
  }

  updatePosition(direction) 
  {
    this.direction = direction;
  }

  isColliding(myImage) 
  {
    return this.currentAnimation.collide(myImage);
  }

  speedMore(){
    this.speed +=.05;

    if (this.speed >= 20){
      this.speed = 19.9;
    }
  }

  speedLess(){
    this.speed -=.1;

    if (this.speed <= 0){
      this.speed = 0;
    }
  } 
  
  turnMore(){
    this.turnRadius +=.2;

    if (this.turnRadius >= 5){
      this.turnRadius = 4.9;
    }
  }

  turnLess(){
    this.turnRadius -=.5;

    if (this.turnRadius <= 3){
      this.turnRadius = 3.1;
    }
  }
}