class level1
{
    conctructor(){

    }

    draw(){

    }
}