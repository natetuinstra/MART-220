class character2
{
    constructor(x,y)
  {
    this.x = x;
    this.y = y;
    
    this.speed = 0;
    this.maxSpeed = 7;
    this.angle = 180;
    this.turnRadius = 3; //higher numbers equal a sharper turn
    this.maxTurnRadius = 5;
    this.currentAnimation;
    this.createAnimation();
  }

  createAnimation() 
  {
    this.currentAnimation = new Sprite(this.x, this.y);
  }

  loadAnimation(animationType, fileNames) 
  {
    this.currentAnimation.addAnimation(animationType, fileNames[0], fileNames[fileNames.length - 1]);
    //hit box
    this.currentAnimation.width = 90;
    this.currentAnimation.height = 90;
  }

  draw(animationType)
  {
    this.currentAnimation.frameDelay = 5;
    this.currentAnimation.scale = 1;
    this.currentAnimation.changeAnimation(animationType);
    this.currentAnimation.rotationLock = true;

    if (animationType == 'right2' && this.direction == 'd') {
      this.angle += this.turnRadius;
      this.currentAnimation.direction = this.angle;
      this.currentAnimation.speed = this.speed;
      this.currentAnimation.rotateTo(this.angle-180,100); //visually rotate image to angle
    }
    else if (animationType == 'left2' && this.direction == 'a') {
      this.angle -= this.turnRadius;
      this.currentAnimation.direction = this.angle;
      this.currentAnimation.speed = this.speed
      this.currentAnimation.rotateTo(this.angle-180,-100); //visually rotate image to angle
    }
    else if (animationType == 'run2' && this.direction == 'w') {
      this.currentAnimation.direction = this.angle;
      this.currentAnimation.speed = this.speed;
    }
    else if(animationType == 'breath2' && this.direction == 'tired') {
        this.currentAnimation.speed = this.speed;
        this.speedLess();
        this.speedLess();
    }
    else if (animationType == 'idle2' && this.direction == 'stopped') {
      this.currentAnimation.speed = this.speed;
    }
    else {
      this.currentAnimation.velocity.x = 0;
      this.currentAnimation.velocity.y = 0;
    }
  }

  updatePosition(direction) 
  {
    this.direction = direction;
  }

  speedMore(){
    this.speed +=.05;

    if (this.speed >= this.maxSpeed){
      this.speed = this.maxSpeed;
    }
  }

  speedLess(){
    this.speed -=.1;

    if (this.speed <= 0){
      this.speed = 0;
    }
  } 
  
  turnMore(){
    this.turnRadius +=.1;

    if (this.turnRadius >= this.maxTurnRadius){
      this.turnRadius = this.maxTurnRadius;
    }
  }

  turnLess(){
    this.turnRadius -=.5;

    if (this.turnRadius <= 3){
      this.turnRadius = 3.1;
    }
  }

  isColliding(myImage) 
  {
    return this.currentAnimation.collides(myImage);
  }

  isOverlapping(myImage){
    return this.currentAnimation.overlaps(myImage);
  }
}