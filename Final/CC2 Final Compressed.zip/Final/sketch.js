//main game operator vars
var game = 0; // 0 - title screen | 1 - game running | 2 - instructions | 3 - game over
var player1Ready = 0;
var player2Ready = 0;
var player1InRing = 0;
var player2InRing = 0;
var player1Score = 0;
var player2Score = 0;

//game operator vars
var momentumConservation = 1; //value 1 = no conservation | higher vaules = more conservation of momentum (keep set to 1 now so hits aren't messed up)
var enduranceIncreaseTime = 105; //amount of time in ms it takes for endurance to increase
var startScreenY = window.innerHeight;
var gameScreen1x = -300;
var gameScreen2x = window.innerWidth + 300;

//player 1 vars
var myAnimation;
var characterX = window.innerWidth/2;
var characterY = window.innerHeight/2;
var hit1 = 0; //used to disable movement to allow bounce when hit
var endurance1 = 100;
var breathing1 = 0;

//player 2 vars
var myAnimation2;
var character2X = window.innerWidth/2;
var character2Y = window.innerHeight/2;
var hit2 = 0; //used to disable movement to allow bounce when hit
var endurance2 = 100;
var breathing2 = 0;

//player 1 animation vars
var idleRed;
var runRed;
var leftRed;
var rightRed;
var diveRed;
var breathRed;

//player 2 animation vars
var idleBlue;
var runBlue;
var leftBlue;
var rightBlue;
var diveBlue;
var breathBlue;

//ring vars
var ringY = window.innerHeight/2;
var ringX = window.innerWidth/2;
var ringDiameter = 750;

//text vars
var japaneseText;
var japaneseTextItalic;

function preload(){
    idleRed = loadStrings("Assets/idleRed.txt");
    runRed = loadStrings("Assets/runRed.txt");
    leftRed = loadStrings("Assets/leftRed.txt");
    rightRed = loadStrings("Assets/rightRed.txt");
    diveRed = loadStrings("Assets/diveRed.txt");
    breathRed = loadStrings("Assets/breathRed.txt");

    idleBlue = loadStrings("Assets/idleBlue.txt");
    runBlue = loadStrings("Assets/runBlue.txt");
    rightBlue = loadStrings("Assets/leftBlue.txt"); //sprites have heads turned wrong way, therefore right and left are intentionally switched
    leftBlue = loadStrings("Assets/rightBlue.txt");
    diveBlue = loadStrings("Assets/diveBlue.txt");
    breathBlue = loadStrings("Assets/breathBlue.txt");

    japaneseText = loadFont("Assets/Font/JAPANESE_2020.otf");
    japaneseTextItalic = loadFont("Assets/Font/JAPANESE_2020 ITALIC.otf")
}

function setup(){
    createCanvas(windowWidth, windowHeight);

    myAnimation = new character(characterX -100, characterY);
    myAnimation.loadAnimation('idle1', idleRed);
    myAnimation.loadAnimation('run1', runRed);
    myAnimation.loadAnimation('left1', leftRed);
    myAnimation.loadAnimation('right1', rightRed);
    myAnimation.loadAnimation('dive1', diveRed);
    myAnimation.loadAnimation('breath1', breathRed);
    
    myAnimation2 = new character2(character2X + 100, character2Y);
    myAnimation2.loadAnimation('idle2', idleBlue);
    myAnimation2.loadAnimation('run2', runBlue);
    myAnimation2.loadAnimation('left2', leftBlue);
    myAnimation2.loadAnimation('right2', rightBlue);
    myAnimation2.loadAnimation('dive2', diveBlue);
    myAnimation2.loadAnimation('breath2', breathBlue);

    //myRing = new ring(window.innerWidth/2, ringY);

    setTimeout(enduranceIncrease,enduranceIncreaseTime); //starts timer
}

function draw(){
    background(50,50,50);

    gameOperator(); //handles the logic for the game to either start or not
    moveCharacter();
    moveCharacter2();
    playerCollision();
    ringCollision(ringX,ringY,ringDiameter/2, myAnimation.currentAnimation.x,myAnimation.currentAnimation.y,45, myAnimation2.currentAnimation.x,myAnimation2.currentAnimation.y,45);
    reset(); //resets hit values once player speed = 0
    drawRing();
    enduranceRegulator(); //keeps endurance from going to low below zero
    enduranceMeterRed(); //graphic  showing player1 endurance
    enduranceMeterBlue(); //graphic  showing player2 endurance
    score();
    drawScreen();// this is at the end so it is all drawn over everything else
}

function gameOperator(){
    //ckecks if player1 is ready
    if(kb.pressing('s')){
        player1Ready = 1;
    }

    //checks if player2 is ready
    if(kb.pressing('k')){
        player2Ready = 1;
    }
    //checks to see if '1' is pressed for instructions
    if(kb.pressing('1')){
        game = 2;
    }
    else {

//checks to see if a player has reached a score of 500 and if so sets game to 3
        if (player1Score >= 500 || player2Score >= 500){
            player1Ready = 0;
            player2Ready = 0;
            game = 3;
        }
//checks to see if both players are ready, and if so the game begins
        else if(player1Ready == 1 && player2Ready ==1){
            setTimeout(gameStart, 5000); //this calls for the game to start, but with a 5 second delay
            if (startScreenY == window.innerHeight){setTimeout(moveStartY1, 1000);}
            if (startScreenY ==  - 900){setTimeout(moveStartY2,1000);}
            if (startScreenY ==  - 1900){setTimeout(moveStartY3,1000);}
            if (startScreenY ==  - 2900){setTimeout(moveStartY4,1000);}
            function gameStart(){
                myAnimation.currentAnimation.visible = true;
                myAnimation2.currentAnimation.visible = true;
                if(player1Ready == 1 && player2Ready ==1){ //this if statement is here to stop the game over screen from flickering before becoming visible
                game = 1;}
            }
        }
        else{game = 0}
    }

//moveStartY# makes countdown work
function moveStartY1(){
    startScreenY = -900;
}
function moveStartY2(){
    startScreenY = -1900;
}
function moveStartY3(){
    startScreenY = -2900;
}
function moveStartY4(){
    startScreenY = -3900;
}
}

function drawScreen(){ //this displays the start screen or instruction screen based off of if statements in function gameOperator
//start screen
if(game == 0){
    myAnimation.currentAnimation.visible = true;
    myAnimation2.currentAnimation.visible = true;
//bg
    fill(50,50,50);
    rect(0,0,window.innerWidth,window.innerHeight);
//ring
    noStroke();
    fill(255,0,0);
    circle(window.innerWidth/2, window.innerHeight/2, 750);
    fill(20,20,20);
    circle(window.innerWidth/2, window.innerHeight/2, 700);
//text bg bar
    fill(20,20,20);
    rect(0,startScreenY-750,window.innerWidth,startScreenY-710);
// SUMO BATTLE text
    textSize(130);
    fill(0,0,255);
    text('SUMO', window.innerWidth/2-425, startScreenY/2-200);
    fill(255,0,0);
    text('Battle', window.innerWidth/2-25, startScreenY/2-200);
//countdown text
    textSize(130);
    fill(50,50,50);
    text('3', window.innerWidth/2-37, startScreenY/2 + 850);
    text('2', window.innerWidth/2-37, startScreenY/2 + 1350);
    text('1', window.innerWidth/2-21, startScreenY/2 + 1850);
    textSize(65);
    text('GO!',window.innerWidth/2-48, startScreenY/2 + 2350);
// player1 text
    if (player1Ready == 0){
        fill(40,40,40);
        textSize(30);
        text('NOT READY', window.innerWidth/2-185, window.innerHeight/2+100);
    }
    else{
        fill(255,0,0);
        textSize(30);
        text('READY', window.innerWidth/2-150, window.innerHeight/2+100);
    }
// player2 text
    if (player2Ready == 0){
        fill(40,40,40);
        textSize(30);
        text('NOT READY', window.innerWidth/2 + 20, window.innerHeight/2+100);
    }
    else{
        fill(0,0,255);
        textSize(30);
        text('READY', window.innerWidth/2 + 50, window.innerHeight/2+100);
    }
// hold '1' for instructions
    fill(0);
    textSize(20);
    text('HOLD 1 FOR INSTRUCTIONS', window.innerWidth/2-120, startScreenY/2-120);
} 
//instructions screen
else if(game == 2){
    myAnimation.currentAnimation.visible = false;
    myAnimation2.currentAnimation.visible = false;
    fill(20,20,20);
    rect(0,0,window.innerWidth,window.innerHeight);
    fill(0,200,0);
    textSize(30);
    text('Knock your opponent out of the ring to earn points. First to 500 points wins.', 50, 50);
    fill(200,0,0);
    text('Player 1 Controls:', 50, 100);
    text('W: forward / A: left / D: right / S: slow / SHIFT: sharp turns / SPACE: dive', 50, 150);
    fill(0,0,200);
    text('Player 2 Controls:', 50, 200);
    text('I: forward / J: left / L: right / K: slow / N: sharp turns / /: dive', 50, 250);
    fill(255);
    text('Endurance is lost as you move. Executing sharp turns or diving', 50, 300);
    text('causes you to lose more endurance.', 50, 350);
    text('If your endurance is running low, you cannot dive.', 50, 400);
    text('If your endurance is out, you cannot move.', 50, 450);
    text('When players collide, the faster player bounces the slower player.', 50, 500);
    fill(150,150,150);
    text('Press the key used to slow down (P1: s / P2: /) to change player status to ready.', 50, 550);
}
//game over screen
if (game == 3){
    myAnimation.currentAnimation.visible = false;
    myAnimation2.currentAnimation.visible = false;

    //player1 win
    if (player1Score >= 500){
        gameScreen1x +=20;
        if(gameScreen1x >= window.innerWidth +300){
            gameScreen1x = window.innerWidth +300
        }
        fill(150,0,0);
        triangle(gameScreen1x-150,0, gameScreen1x+300,0, gameScreen1x-150,900);
        rect(0,0,gameScreen1x-150,window.innerHeight);
        fill(255);
        textSize(100);
        text('Red Wins',gameScreen1x-1300,window.innerHeight/2);
        fill(255,100,100);
        textSize(50);
        text('Press F5 to Reset',gameScreen1x-1301,window.innerHeight/2 + 50);
    }

    //player2 win
    if (player2Score >= 500){
        gameScreen2x -=20;
        if(gameScreen2x <= -300){
            gameScreen2x = -300
        }
        fill(0,0,150);
        triangle(gameScreen2x+150,0, gameScreen2x - 300,0, gameScreen2x+150,900);
        rect(gameScreen2x+150,0,window.innerWidth + 300,window.innerHeight);
        fill(255);
        textSize(100);
        text('Blue Wins',gameScreen2x+760,window.innerHeight/2);
        fill(100,100,255);
        textSize(50);
        text('Press F5 to Reset',gameScreen2x+780,window.innerHeight/2 + 50);
    }
}
}

function moveCharacter(){
//animation and positioning
     if(endurance1 < 0){
        endurance1 -=.125;
        myAnimation.updatePosition('tired');
        myAnimation.draw('breath1');
    }
    else if (kb.pressing('d') && myAnimation.speed > .2 && hit1 == 0 && game ==1) {
        myAnimation.updatePosition('d');
        myAnimation.draw('right1');
        // endurance modifier
        endurance1 -= .2;
    }
    else if (kb.pressing('a')&& myAnimation.speed > .2 && hit1 == 0 && game ==1) {
        myAnimation.updatePosition('a');
        myAnimation.draw('left1');
        // endurance modifier
        endurance1 -= .2;
    }
    else if (kb.pressing('w') && hit1 == 0 && game ==1) {
        myAnimation.updatePosition('w');
        myAnimation.draw('run1');
        // endurance modifier
        endurance1 -= .2;
    }
    else {
        myAnimation.updatePosition('stopped');
        myAnimation.draw('idle1');
    }

//speed
    if (kb.pressing('w') && hit1 == 0 && game ==1) {
        myAnimation.speedMore();
    }
    else {
        myAnimation.speedLess();
    }

//drift
    if (kb.pressing('shift') && hit1 == 0 && game ==1) {
        myAnimation.turnMore();
        // endurance modifier
        endurance1 -= .1;
    }
    else {
        myAnimation.turnLess();
    }

//brake
    if (kb.pressing('s') && game ==1) {
        myAnimation.speedLess();
        myAnimation.speed -=.05;
    }

//dash
    if (kb.pressing(' ') && hit1 == 0 && endurance1 > 35 && game ==1) {
            if(myAnimation.speed > 0) {
                myAnimation.draw('dive1');
                myAnimation.maxSpeed = 12;
                myAnimation.speed = myAnimation.maxSpeed;
                myAnimation.currentAnimation.direction = myAnimation.angle; //ensures dash is in right direction
                // endurance modifier
                endurance1 -= 5;
                setTimeout(reset,100);
            }
    }
}

function moveCharacter2(){
    //animation and positioning
        if(endurance2 < 0){
            endurance2 -=.125;
            myAnimation2.updatePosition('tired');
            myAnimation2.draw('breath2');
        }
        else if (kb.pressing('l') && myAnimation2.speed > .2 && hit2 == 0 && game ==1) {
            myAnimation2.updatePosition('d');
            myAnimation2.draw('right2');
            // endurance modifier
            endurance2 -= .2;
        }
        else if (kb.pressing('j')&& myAnimation2.speed > .2 && hit2 == 0 && game ==1) {
            myAnimation2.updatePosition('a');
            myAnimation2.draw('left2');
            // endurance modifier
            endurance2 -= .2;
        }
        else if (kb.pressing('i') && hit2 == 0 && game ==1) {
            myAnimation2.updatePosition('w');
            myAnimation2.draw('run2');
            // endurance modifier
            endurance2 -= .2;
        }
        else {
            myAnimation2.updatePosition('stopped');
            myAnimation2.draw('idle2');
        }
    
    //speed
        if (kb.pressing('i') && hit2 == 0 && game ==1) {
            myAnimation2.speedMore();
        }
        else {
            myAnimation2.speedLess();
        }
    
    //drift
        if (kb.pressing('n') && hit2 == 0 && game ==1) {
            myAnimation2.turnMore();
            // endurance modifier
            endurance2 -= .1;
        }
        else {
            myAnimation2.turnLess();
        }
    
    //brake
        if (kb.pressing('k') && game ==1) {
            myAnimation2.speedLess();
            myAnimation2.speed -=.05;
        }
    //dash
        if (kb.pressing('/') && hit2 == 0 && endurance2 > 35 && game ==1) {
            
            if(myAnimation2.speed > 0) {
                myAnimation2.draw('dive2');
                myAnimation2.maxSpeed = 12;
                myAnimation2.speed = myAnimation2.maxSpeed;
                myAnimation2.currentAnimation.direction = myAnimation2.angle; //ensures dash is in right direction
                // endurance modifier
                endurance2 -= 5;
                setTimeout(reset,100);
            }
        }
}

function playerCollision(){
    //checks for player collision
    if(myAnimation.isColliding(myAnimation2.currentAnimation))
    {
        //red hits blue || player1 hits player2
        if (myAnimation.speed > myAnimation2.speed){
            myAnimation2.speed = myAnimation.speed;
            myAnimation.speed -= myAnimation.speed/momentumConservation;
            stop2(); //stops player 2
        }
        //blue hits red
        else {
            myAnimation.speed = myAnimation2.speed;
            myAnimation2.speed -= myAnimation2.speed/momentumConservation;
            stop1(); //stops player 1
        }
    } 
    
    function stop2(){
        hit2 = 1;
    }
    
    function stop1(){
        hit1 = 1;
    }
}

function ringCollision(rX,rY,rR, p1x,p1y,p1r, p2x,p2y,p2r){
    //finds distance from center of ring to player1
    const distance1x = rX - p1x;
    const distance1y = rY - p1y;
    const rP1Distance = Math.sqrt(distance1x * distance1x + distance1y * distance1y);

    //finds distance from center of ring to player2
    const distance2x = rX - p2x;
    const distance2y = rY - p2y;
    const rP2Distance = Math.sqrt(distance2x * distance2x + distance2y * distance2y);

    //detects if player1 is within the ring
    if (rP1Distance < rR + p1r){
        player1InRing = 0;
    }
    else if (rP1Distance > rR + p1r){
        player1InRing = 1;
    }

    //detects if player2 is within the ring
    if (rP2Distance < rR + p2r){
        player2InRing = 0;
    }
    else if (rP2Distance > rR + p2r){
        player2InRing = 1;
    }
}

function reset(){
    if (myAnimation.speed == 0){
        hit1 = 0;
    }

    if (myAnimation2.speed == 0){
        hit2 = 0;
    }

    if (myAnimation.maxSpeed = 12){
        myAnimation.maxSpeed = 7;
    }

    if (myAnimation2.maxSpeed = 12){
        myAnimation2.maxSpeed = 7;
    }
}

function enduranceIncrease(){
    setTimeout(enduranceIncrease,enduranceIncreaseTime);

    if (endurance1 < 100){
        endurance1 ++;
    }
    if (endurance2 < 100){
        endurance2 ++;
    }
}

function enduranceRegulator(){
    if (endurance1 <=-10){
        endurance1 += .5;
    }

    if (endurance2 <=-10){
        endurance2 += .5;
    }
}

function enduranceMeterRed(){
    //bg triangle
    fill(150,0,0);
    triangle(0,0, 300,0, 0,600);

    //endurance bar bg
    fill(100,0,0);
    rect (25,500,215,-430);

    //endurance bar
    fill(20,20,20);
    rect (25,500,215,-endurance1*4.3);

    //endurance text
    fill(255,0,0);
    textSize(40); 
    textFont(japaneseText);
    text('endurance',10,50);
   
    //fg endurance triangle (covers up the endurance bar so it appears to be a triangle)
    fill(150,0,0);
    triangle(240,70, 240,500, 25,500);

    //fg endurance rect (covers up the endurance bar for when it goes negative)
    fill(150,0,0);
    rect(25,500,215,100);

    //fg triangle (covers up the previous traingle)
    fill(50,50,50);
    triangle(300,600, 0,600, 300,0);
}

function enduranceMeterBlue(){
    //bg triangle
    fill(0,0,150);
    triangle(window.innerWidth,0, window.innerWidth - 300,0, window.innerWidth,600);

    //endurance bar bg
    fill(0,0,100);
    rect (window.innerWidth - 240,500,215,-430);

    //endurance bar
    fill(20,20,20);
    rect (window.innerWidth - 240,500,215,-endurance2*4.3);

    //endurance text
    fill(0,0,255); 
    textSize(40);
    textFont(japaneseText);
    text('endurance',window.innerWidth -260,50);
    
    //fg endurance triangle (covers up the endurance bar so it appears to be a triangle)
    fill(0,0,150);
    triangle(window.innerWidth -240,70, window.innerWidth -240,500, window.innerWidth -25,500);

    //fg endurance rect (covers up the endurance bar for when it goes negative)
    fill(0,0,150);
    rect(window.innerWidth - 125,500, 215,100);

    //fg triangle (covers up the previous traingle)
    fill(50,50,50);
    triangle(window.innerWidth - 300,600, window.innerWidth,600, window.innerWidth -300,0);
}

function drawRing(){
    noStroke();
    fill(255,0,0);
    circle(ringX, ringY, ringDiameter);
    fill(20,20,20);
    circle(ringX, ringY, ringDiameter-50);
}

function score(){
    if(player1InRing == 1 && game == 1){
        player2Score +=1;

        if (player2Score >= 500){
            player2Score = 500;
        }
    }
    if(player2InRing == 1 && game == 1){
        player1Score +=1;

        if (player1Score >= 500){
            player1Score = 500;
        }
    }

    fill(255,150,150);
    text(''+ player1Score,window.innerWidth/2-320,window.innerHeight - 50);
    fill(150,150,255);
    text(''+ player2Score,window.innerWidth/2+300,window.innerHeight - 50);
}