var characterX = window.innerWidth/2;
var characterY = window.innerHeight/2;

var idleStrings;
var runStrings;

function preload(){
    idleStrings = loadStrings("Assets/idle.txt");
    runStrings = loadStrings("Assets/run.txt");
}

function setup(){
    createCanvas(window.innerWidth, window.innerHeight);

    myAnimation = new character(characterX, characterY);
    myAnimation.loadAnimation('idle', idleStrings);
    myAnimation.loadAnimation('run', runStrings);
}

function draw(){
    background(49,0,71);

    moveCharacter();
}

function moveCharacter(){
    if (kb.pressing('d')) {
        myAnimation.updatePosition('forward');
        myAnimation.draw('run');
        myAnimation.speedMore();
    }
    else if (kb.pressing('a')) {
        myAnimation.updatePosition('reverse');
        myAnimation.draw('run');
        myAnimation.speedMore();
    }
    else if (kb.pressing('w')) {
        myAnimation.updatePosition('up');
        myAnimation.draw('run');
        myAnimation.speedMore();
    }
    else if (kb.pressing('s')) {
        myAnimation.updatePosition('down');
        myAnimation.draw('run');
        myAnimation.speedMore();
    }
    else {
        myAnimation.updatePosition('stopped');
        myAnimation.draw('idle');
        myAnimation.speedLess();
    }
}