class food
{
    constructor(x,y,isGood)
    {
        this.x = x;
        this.y = y;
        this.isGood = isGood;
        if(isGood){
        this.foodPiece = new Sprite(x, y, 30);
        }
        else{
        this.foodPiece = new Sprite(x, y, 30,'static');
        }
    }

    draw(){
        if (this.isGood)
        {
        this.foodPiece.color = "green"
        }
        else
        {
        this.foodPiece.color = "red"
        }
    }
}