var animation = [];
var runAnimation = [];
var jumpAnimation = [];
var i = 0;
var f;
var myCharacter;
var characterX = 100;
var characterY = 100;
var idleStrings;
var runStrings;
var jumpStrings;
var flipX = false;
var myFood;
var foodArray = [];
var badFoodArray = [];
var foodAmount = 5; //affects both good and bad food amount
var score = 0;
var gameTime = 60; //in seconds
var winTextX = 0;
var winTextY = 0;
var lossTextX = 0;
var lossTextY = 0;
var bgSound;
var badSound;
var goodSound;
var lives = 3;
var particleArray = [];
var enemyHealth = 100;
var enemyCount = 5; //MUST MAKE THIS MATCH foodAmount !!!
var myParticle;

//loads character images
function preload()
{
    soundFormats('mp3', 'ogg', 'wav');
    bgSound = loadSound("Assets/Sounds/looping-hiphop-beat.wav");
    badSound = loadSound("Assets/Sounds/badFood.mp3");
    goodSound = loadSound("Assets/Sounds/biting-apple.mp3");
    idleStrings = loadStrings("Assets/idle.txt");
    runStrings = loadStrings("Assets/run.txt");
    jumpStrings = loadStrings("Assets/jump.txt");
    
}

function setup()
{
    let myCanvas = createCanvas(1480,725);
    setTimeout(gameEnd, gameTime*1000);
    setInterval(countdown, 1000);
    setInterval(randomizeFood, 5000);

    myAnimation = new character(characterX, characterY);
    myAnimation.loadAnimation('idle', idleStrings);
    myAnimation.loadAnimation('run', runStrings);
    myAnimation.loadAnimation('jump', jumpStrings);

    //passes info into food class
    for (var f = 0; f < foodAmount; f++) 
        {
            myFood = new food(random(100, 1380), random(100, 625), true);
            foodArray.push(myFood);

            //bad food
            myFood = new food(random(100,1380), random(100,625), false);
            badFoodArray.push(myFood);
        } 

    myCanvas.mousePressed(playBackgroundSound);
}

function draw()
{
    background(0);
    displayFoods();
    moveCharacter();
    collision();
    displayScoreText();
    displayCountdown();
    displayWinLose();
    displayHealth();

    displayObjectAnimation();
}

//animation to indicate when food randomizes
function displayObjectAnimation()
{
    fill(255,255,255);
    animS.rect('r1', 380, 50, 670, 20, 20);
}

//called in draw
function displayFoods()
{
    //draws the food
    for (let f = 0; f < foodArray.length; f++) 
    {
        foodArray[f].draw();
    }

    //draws the bad food
    for (let b = 0; b < badFoodArray.length; b++) 
    {
        badFoodArray[b].draw();
    }
}

//called in draw
function moveCharacter()
{
    if (kb.pressing('d')) 
    {
        myAnimation.updatePosition('forward');
        myAnimation.draw('run');
    }
    else if (kb.pressing('a')) 
    {
        myAnimation.updatePosition('reverse');
        myAnimation.draw('run');
    }
    else if (kb.pressing('w')) 
    {
        myAnimation.updatePosition('up');
        myAnimation.draw('run');
    }
    else if (kb.pressing('s')) 
    {
        myAnimation.updatePosition('down');
        myAnimation.draw('run');
    }
    else if (kb.pressing('space'))
    {
        myAnimation.draw('jump');
    }
    
    else 
    {
        myAnimation.draw('idle');
    }
}

//called in draw
function collision()
{
    //good food collision
    for(let f = 0; f < foodArray.length; f++)
    {
        if(myAnimation.isColliding(foodArray[f].foodPiece))
        {
            score++;
            goodSound.play();                
            foodArray[f].foodPiece.remove();
        } 
    }

    //bad food collision
    for(let b = 0; b < badFoodArray.length; b++)
        {
            if(myAnimation.isColliding(badFoodArray[b].foodPiece))
                {
                    console.log('is colliding');
                } 


            if(myAnimation.isColliding(badFoodArray[b].foodPiece) && (kb.pressing('space')))
            {
                enemyHealth --;
                    
                        for (let i = 0; i < 5; i++) {
                            let p = new particle(badFoodArray[b].foodPiece.x,badFoodArray[b].foodPiece.y);
                            particleArray.push(p);
                          }
                          for (let i = particleArray.length - 1; i >= 0; i--) {
                            particleArray[i].update();
                            particleArray[i].show();
                            if (particleArray[i].finished()) {
                              // remove this particle
                              particleArray.splice(i, 1);
                            }
                          }
            } 

            if(myAnimation.isColliding(badFoodArray[b].foodPiece) && enemyHealth <= 0)
            {
                particleArray = []
                badFoodArray[b].foodPiece.remove();
                enemyHealth = 100;
                enemyCount --;
            }
        }
}

//randomizes food and resets animation indicating food rando
function randomizeFood()
{
    for (var f = 0; f < foodArray.length; f++) 
        {
            foodArray[f].x = random(50,1430);
            foodArray[f].y = random(50,680);
        }

    for (var b = 0; b < badFoodArray.length; b++) 
        {
            badFoodArray[b].x = random(50,1430);
            badFoodArray[b].y = random(50,680);
        }

    animS.reset();
}

//called in draw
function displayScoreText()
{
    fill(255,255,255);
    textSize(30);
    text('Score:' + score, 10, 30);
}

function countdown()
{
        gameTime -=1;    
}

//called in draw
function displayCountdown()
{
    fill(255,255,255);
    textSize(30);
    text('Time Left:' + gameTime + 's', 1280, 30);
}

function displayHealth()
{
    text("Lives:" + lives, 700, 700);

    if (lives <=0)
    {
        lives = 0;
        gameEnd();
    }
}

function gameEnd()
{
    winTextX = 700;
    winTextY = 300;
    lossTextX = 700;
    lossTextY = 300;
    myAnimation.speed = 0;
}

//called in draw
function displayWinLose()
{
    if(score < foodAmount && enemyCount > 0)
    {
        fill(255,255,255);
        textSize(30);
        text('Loss',lossTextX,lossTextY);
    } 
    else 
    {
        fill(255,255,255);
        textSize(30);
        text('Win',winTextX,winTextY); 
    }

    if(score >= foodAmount && enemyCount == 0)
    {
        fill(255,255,255);
        textSize(30);
        text('Win',winTextX,winTextY);
        winTextX = 700;
        winTextY = 300;
        gameEnd();
    }

    if(enemyCount == 0)
        {
            fill(255,255,255);
            textSize(30);
            text('Win',winTextX,winTextY);
            winTextX = 700;
            winTextY = 300;
            gameEnd();
        }
}

function playBackgroundSound()
{
    bgSound.play();
}