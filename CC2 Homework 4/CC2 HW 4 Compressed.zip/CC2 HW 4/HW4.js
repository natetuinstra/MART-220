var animation = [];
var i = 0;
var mySprite

function preload(){
    for(var i = 1; i< 16; i++)
        {
            mySprite = new sprite("Assets/Images/Idle (" + i + ").png");  
            animation.push(mySprite);
        }
}

function setup(){
    createCanvas(1480,725);
    setInterval(updateIndex, 50);
}

function draw(){
    background(0);
    animation[i].draw();
}

function updateIndex(){
    i++;
    if(i > 14)
    {
        i = 0;
    }  
}