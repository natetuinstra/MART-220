function setup() {
    createCanvas(600, 400);
    background(240);
    drawPlate();
    drawBurger(250, 200);
    drawFries(400, 200);
  }
  
  function drawPlate() {
    fill(255);
    stroke(200);
    strokeWeight(5);
    ellipse(300, 200, 350, 250);
  }
  
  function drawBurger(x, y) {
    // Bottom bun
    fill(210, 180, 140);
    ellipse(x, y + 30, 120, 40);
    
    // Lettuce
    fill(60, 179, 113);
    ellipse(x, y + 15, 130, 30);
    
    // Patty
    fill(139, 69, 19);
    ellipse(x, y, 120, 40);
    
    // Top bun
    fill(210, 180, 140);
    ellipse(x, y - 20, 120, 50);
  }
  
  function drawFries(x, y) {
    fill(255, 204, 0);
    rect(x, y - 50, 20, 80, 5);
    rect(x + 25, y - 60, 20, 90, 5);
    rect(x + 50, y - 40, 20, 70, 5);
    rect(x + 75, y - 55, 20, 85, 5);
  }