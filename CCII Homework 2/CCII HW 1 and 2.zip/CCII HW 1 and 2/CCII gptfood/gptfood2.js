let plate;
let fries = [];
let numFries = 10;

function setup() {
  createCanvas(800, 600);
  
  // Initialize plate position
  plate = createVector(width / 2, height / 2);
  
  // Create fries
  for (let i = 0; i < numFries; i++) {
    fries[i] = createVector(random(width), random(height));
  }
}

function draw() {
  background(220);
  
  // Draw plate
  drawPlate(plate.x, plate.y);
  
  // Draw burger
  drawBurger(plate.x, plate.y);
  
  // Draw fries
  for (let fry of fries) {
    drawFries(fry.x, fry.y);
  }
  
  // Update fries position randomly
  for (let fry of fries) {
    fry.x += random(-1, 1);
    fry.y += random(-1, 1);
    
    // Keep fries within canvas
    fry.x = constrain(fry.x, 0, width);
    fry.y = constrain(fry.y, 0, height);
  }
}

function drawPlate(x, y) {
  fill(255);
  ellipse(x, y, 200, 200); // Plate size
}

function drawBurger(x, y) {
  fill(139, 69, 19); // Brown for the bun
  ellipse(x, y, 100, 50); // Burger bun
  fill(255, 0, 0); // Red for tomato
  ellipse(x, y, 80, 30); // Tomato
  fill(0, 255, 0); // Green for lettuce
  ellipse(x, y, 90, 35); // Lettuce
  fill(255, 215, 0); // Yellow for cheese
  rect(x - 40, y - 10, 80, 10); // Cheese slice
}

function drawFries(x, y) {
  fill(255, 215, 0); // Yellow for fries
  rect(x, y, 10, 30); // Fry size
}

function keyPressed() {
  if (key === 'A' || key === 'a') {
    plate.x -= 10; // Move left
  } else if (key === 'D' || key === 'd') {
    plate.x += 10; // Move right
  } else if (key === 'W' || key === 'w') {
    plate.y -= 10; // Move up
  } else if (key === 'S' || key === 's') {
    plate.y += 10; // Move down
  }
}