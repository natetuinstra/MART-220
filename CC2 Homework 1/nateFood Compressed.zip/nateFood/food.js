var centerX = 740;
var centerY = 362.5;

function setup(){
    createCanvas(1480,725);
}

function draw(){
    background(150);

//calls plate
plate(centerX,centerY);

//calls burger
burger(centerX,centerY);

//calls lettuce
lettuce(centerX,centerY,50,30,centerX-10,centerY+5);

//calls ketchup
ketchup(centerX,centerY);

//calls fries
fries(centerX,centerY);
}

function plate(x,y){
    fill(255);
    stroke(200);
    strokeWeight(15);
    ellipse(x,y+20,800,300);
}

function burger(x,y){
//shadow
    fill(200,200,200);
    noStroke();
    ellipse(x-200,y+80,220,20);

//bottom bun
    fill(160,100,0);
    noStroke();
    rect(x-300,y+50,200,30,10);
    //lighting
    fill(200,120,0);
    noStroke();
    rect(x-290,y+65,160,10,10);
    rect(x-290,y+60,10,15,10);
    
//bottom patty
    fill(50,20,0);
    noStroke();
    rect(x-300,y+25,200,30,10);
    //lighting
    fill(80,30,0);
    noStroke();
    rect(x-290,y+40,160,10,10);
    rect(x-290,y+35,10,15,10);

//bottom cheese
    fill(255,255,0);
    noStroke();
    triangle(x-250,y+25,x-150,y+25,x-200,y+65,);
    //lighting
    fill(255,255,255);
    stroke(255,255,255);
    strokeWeight(5);
    line(x-235,y+30,x-205,y+55);

//top patty
    fill(50,20,0);
    noStroke();
    rect(x-300,y-5,200,30,10);
    //lighting
    fill(80,30,0);
    noStroke();
    rect(x-290,y+10,160,10,10);
    rect(x-290,y+5,10,15,10);

//top cheese
    fill(255,255,0);
    noStroke();
    triangle(x-250,y-5,x-150,y-5,x-200,y+35,);
    //lighting
    fill(255,255,255);
    stroke(255,255,255);
    strokeWeight(5);
    line(x-235,y,x-205,y+25);

//lettuce is outside of burger function

//top bun
    fill(200,120,0);
    noStroke();
    rect(x-300,y-35,200,30,10);
    ellipse(x-200,y-30,200,80);

//seeds
    fill(255,220,0);
    noStroke();
    ellipse(x-190,y-27,5,10);
    ellipse(x-180,y-30,5,10);
    ellipse(x-240,y-32,5,10);
    ellipse(x-260,y-37,5,10);
    ellipse(x-290,y-33,5,10);
    ellipse(x-170,y-29,5,10);
    ellipse(x-140,y-31,5,10);
    ellipse(x-130,y-34,5,10);
    ellipse(x-160,y-36,5,10);
    ellipse(x-185,y-42,5,10);
    ellipse(x-163,y-45,5,10);
    ellipse(x-215,y-44,5,10);
    ellipse(x-205,y-43,5,10);
}

function lettuce(x,y,length,width,x2,y2){
    fill(0,150,0);
    noStroke();
    ellipse(x-120,y,length,width);
    fill(0,200,0);
    ellipse(x2-120,y2,20,10);

    fill(0,150,0);
    noStroke();
    ellipse(x-140,y+2,length,width);
    fill(0,200,0);
    ellipse(x2-140,y2+2,20,10);

    fill(0,150,0);
    noStroke();
    ellipse(x-160,y-4,length,width);
    fill(0,200,0);
    ellipse(x2-160,y2-4,20,10);

    fill(0,150,0);
    noStroke();
    ellipse(x-190,y,length,width);
    fill(0,200,0);
    ellipse(x2-190,y2,20,10);

    fill(0,150,0);
    noStroke();
    ellipse(x-210,y-4,length,width);
    fill(0,200,0);
    ellipse(x2-210,y2-4,20,10);

    fill(0,150,0);
    noStroke();
    ellipse(x-240,y+1,length,width);
    fill(0,200,0);
    ellipse(x2-240,y2+1,20,10);

    fill(0,150,0);
    noStroke();
    ellipse(x-280,y-2,length,width);
    fill(0,200,0);
    ellipse(x2-280,y2-2,20,10);
}

function ketchup(x,y){
    //shadow
    fill(200,200,200);
    ellipse(x+90,y+95,155,50)

    fill(220,0,0);
    noStroke();
    ellipse(x+90,y+90,150,40);
    //lighting
    fill(255,220,220);
    ellipse(x+70,y+95,80,20);
}

function fries(x,y){
//shadow
    fill(200,200,200);
    ellipse(x+120,y,200,50);
    ellipse(x+220,y+20,200,50);

    stroke(255,220,0);
    strokeWeight(10);
    line(x+100,y-10,x+200,y);
    line(x+110,y-20,x+190,y-10);
    line(x+90,y,x+220,y-30);
    line(x+80,y-20,x+170,y+10);
    line(x+60,y+20,x+190,y-10);
    line(x,y+40,x+130,y+10);
    line(x+10,y-40,x+150,y-45);
    line(x+15,y+35,x+145,y-30);

    line(x+200,y+40,x+300,y+15);
    line(x+210,y,x+290,y);
    line(x+190,y+20,x+320,y-10);
    line(x+180,y,x+270,y+20);
    line(x+160,y+40,x+290,y);
    line(x+175,y+60,x+230,y+30);
    line(x+140,y-50,x+250,y-25);
    line(x+115,y+55,x+245,y-10);
}
