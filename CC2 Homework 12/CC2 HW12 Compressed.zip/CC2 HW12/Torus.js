class Torus extends threeDShape{

    constructor(x, y, z, speedX, speedY, speedZ, radius, tubeRadius)
    {
        super(x,y,z, speedX, speedY, speedZ);
        this.radius = radius;
        this.tubeRadius = tubeRadius;
    }

    draw()
    {
        push();
        super.moveShape();
        torus(this.radius, this.tubeRadius);
        pop();
    }
}