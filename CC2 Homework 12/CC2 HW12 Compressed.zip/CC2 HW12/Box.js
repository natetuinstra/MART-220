class Box extends threeDShape
{
    constructor(x, y, z, speedX, speedY, speedZ, width, height)
    {
        super(x,y,z, speedX, speedY, speedZ);
        this.width = width;
        this.height = height;
    }

    draw()
    {
        push();
        super.moveShape();
        box(this.width, this.height);
        pop();
    }

}