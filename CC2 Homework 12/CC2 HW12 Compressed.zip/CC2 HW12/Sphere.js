class Sphere extends threeDShape{

    constructor(x, y, z, speedX, speedY, speedZ, radius)
    {
        super(x,y,z, speedX, speedY, speedZ);
        this.radius = radius;
    }

    draw()
    {
        push();
        super.moveShape();
        sphere(this.radius);
        pop();
    }
}