var shape0, shape1, shape2, shape3, shape4;
var shapes = [];

var cubeTexture;
var silverTexture;
var myFont;

function preload(){
    goldTexture = loadImage("assets/goldTexture.jpg");
    silverTexture = loadImage("assets/silverTexture.jpg");
    bronzeTexture = loadImage("assets/bronzeTexture.jpg");
    myFont = loadFont("assets/Underdog-Regular.ttf");
}

function setup(){
    createCanvas(1480,725,WEBGL);

    shape0 = new Box(random(-500,500), random(-300,300), random(-300,300), .05, .05, 0, 30, 30);
    shape1 = new Torus(random(-500,500), random(-300,300), random(-300,300), .0, .05, 0, 50, 20);
    shape2 = new Torus(random(-500,500), random(-300,300), random(-300,300), .05, 0, 0, 100, 25);
    shape3 = new Sphere(random(-500,500), random(-300,300), random(-300,300), -.05, 0, 0, 50);
    shape4 = new Sphere(random(-500,500), random(-300,300), random(-300,300), -.05, 0, 0, 50);
   
    shapes[0] = shape0;
    shapes[1] = shape1;
    shapes[2] = shape2;
    shapes[3] = shape3;
    shapes[4] = shape4;
}

function draw(){
    background(108,118,98);

    noStroke();

    texture(silverTexture);
    shapes[0].draw();

    normalMaterial();
    shapes[1].draw();

    texture(goldTexture);
    shapes[3].draw();
    texture(bronzeTexture);
    shapes[4].draw();

    ambientLight(255);
    ambientMaterial(255);
    shapes[2].draw();

    fill(255,255,255);
    textFont(myFont);
    textSize(30);
    text("Random Objects in Random Places",-720,-300);
    text("Nate Tuinstra",-720,-260);
}