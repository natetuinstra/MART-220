class character
{
    constructor(path,x,y) //these parmeters are passed in from the new character within HW5.js
    {
        this.path = path;
        this.myImage = loadImage(this.path);
        this.x = x;
        this.y = y;
        this.imageWidth = 200;
        this.imageHeight = 200;
    }

    draw()
    {
        image(this.myImage, this.x, this.y, this.imageWidth, this.imageHeight);
    }

    hasCollided(x2, y2, w2, h2) {
        return (
          this.x < x2 + w2 &&
          this.x +  this.imageWidth - 100 > x2 &&
          this.y < y2 + h2 &&
          this.y + this.imageHeight > y2
        );
      }
}