class food
{
    constructor(x,y)
    {
        this.x = x;
        this.y = y;
    }

    draw(){
        fill(random(0,255),random(0,255),random(0,255));
        circle(this.x, this.y, 25);
        fill(0);
        circle(this.x, this.y, 10);
    }
}