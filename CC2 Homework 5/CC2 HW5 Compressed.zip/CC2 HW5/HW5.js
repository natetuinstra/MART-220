var animation = [];
var i = 0;
var myCharacter;
var characterX = 100;
var characterY = 100;
var speed = 5;

var myFood;
var foodArray = [];
var foodAmount = 10;
//loads character and passes info into character class
function preload()
{
    for(var i = 1; i< 16; i++)
        {
            myCharacter = new character("Assets/Images/Idle (" + i + ").png", characterX, characterY);  
            animation.push(myCharacter);
        }
}

function setup()
{
    createCanvas(1480,725);
    setInterval(updateIndex, 50);

    //used to generate food
    for (let i = 0; i < foodAmount; i++) 
    {
        myFood = new food(random(0, 1480), random(0, 725));
        foodArray.push(myFood);
    }
}

function draw()
{
    background(0);
    animation[i].draw();

    //spills food all over the canvas :(
    for (let i = 0; i < foodArray.length; i++) 
    {
        foodArray[i].draw();
    }

    //character movement 
    if (keyIsPressed) 
    {
        if (key == "a") {
            characterX-= speed;
        }
        if (key == "d") {
            characterX+= speed;
        }
        if (key == "w") {
            characterY-= speed;
        }
        if (key == "s") {
            characterY+= speed;
        }

           for (let i = 0; i < 15; i++)
           {
                animation[i].x = characterX;
                animation[i].y = characterY;
           }

           for (let k = 0; k < foodArray.length; k++) {
            if (animation[i].hasCollided(foodArray[k].x, foodArray[k].y, 25, 25)) {
                foodArray.splice(k, 1);
                }}
    }
    
}

function updateIndex()
{
    i++;
    if(i > 14)
    {
        i = 0;
    }  
}