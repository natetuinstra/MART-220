//declares center of canvas - most numbers are based from here(this was a terrible idea)
var centerX = 740;
var centerY = 362.5;

//used to move ketchup randomly upon refresh
var centerX2 = 740;
var centerY2 = 362.5;

//used to move cheese randomly upon refresh
var centerX3 = 740;
//used to move cheese randomly upon refresh
var centerX4 = 740;

//used for movement of lettuce
var centerX5 = 740;

//used for fries
var centerY3 = 362.5;

//player vars
var playerx = 740;
var playery = 362.5;

//var to allow for an object to randomly move (used for the lettuce and fries)
var randomMove;

//image variables
slothCorvetteX = 400;
slothCorvetteY = 50;

couchPotatoX = 500;
couchPotatoY = 50;
//potatoSpeedX = (random(-10,10));
//potatoSpeedY = (random(-10,10));

//font variable
var pinkyShow;


function setup(){
    createCanvas(1480,725);

    centerX2 += (random(-50,50));
    centerY2 += (random(-30,30));

    centerX3 += (random(-40,40));

    centerX4 += (random(-40,40));

    //load images
    slothCorvette = loadImage('Assets/Images/slothCorvette.jpg');
    couchPotato = loadImage('Assets/Images/couchPotato.jpg');
    manTV = loadImage('Assets/Images/manTV.jpg');

    //load font
    pinkyShow = loadFont('Assets/Font/Pinky Show.otf');

    //timer for image
    setInterval(imageTimer,5000);

    //these only work in setup???
    potatoSpeedX = (random(-10,10));
    potatoSpeedY = (random(-10,10));
}

function draw(){
background(150);

//calls plate (also player)
plate(playerx,playery);
playerMove(83,65,87,68,5);

//calls burger
burger(centerX,centerY,centerX3,centerX4);

//calls lettuce
lettuce(centerX5,centerY,50,30,centerX5-10,centerY+5);

//calls ketchup
ketchup(centerX2,centerY2);

//calls fries
fries(centerX,centerY3);

//calls words
words();

//call images
imagesAI(slothCorvetteX,slothCorvetteY, couchPotatoX,couchPotatoY);

//call couchPotato movement
couchPotatoMove();
}

function plate(x,y){
    fill(255);
    stroke(200);
    strokeWeight(15);
    ellipse(x,y+20,800,300);
}

//plate movement
function playerMove(w,a,s,d,speed){
    if (keyIsDown(a)) {
        playerx -= speed;
      } else if (keyIsDown(d)) {
        playerx += speed;
      }

      if (keyIsDown(s)) {
        playery -= speed;
      } else if (keyIsDown(w)) {
        playery += speed;
      }
}

function burger(x,y,cheesex,cheese1x){
//shadow
    fill(200,200,200);
    noStroke();
    ellipse(x-200,y+80,220,20);

//bottom bun
    fill(160,100,0);
    noStroke();
    rect(x-300,y+50,200,30,10);
    //lighting
    fill(200,120,0);
    noStroke();
    rect(x-290,y+65,160,10,10);
    rect(x-290,y+60,10,15,10);
    
//bottom patty
    fill(50,20,0);
    noStroke();
    rect(x-300,y+25,200,30,10);
    //lighting
    fill(80,30,0);
    noStroke();
    rect(x-290,y+40,160,10,10);
    rect(x-290,y+35,10,15,10);

//bottom cheese
    fill(255,255,0);
    noStroke();
    triangle(cheesex-250,y+25,cheesex-150,y+25,cheesex-200,y+65,);
    //lighting
    fill(255,255,255);
    stroke(255,255,255);
    strokeWeight(5);
    line(cheesex-235,y+30,cheesex-205,y+55);

//top patty
    fill(50,20,0);
    noStroke();
    rect(x-300,y-5,200,30,10);
    //lighting
    fill(80,30,0);
    noStroke();
    rect(x-290,y+10,160,10,10);
    rect(x-290,y+5,10,15,10);

//top cheese
    fill(255,255,0);
    noStroke();
    triangle(cheese1x-250,y-5,cheese1x-150,y-5,cheese1x-200,y+35,);
    //lighting
    fill(255,255,255);
    stroke(255,255,255);
    strokeWeight(5);
    line(cheese1x-235,y,cheese1x-205,y+25);

//lettuce is outside of burger function

//top bun
    fill(200,120,0);
    noStroke();
    rect(x-300,y-35,200,30,10);
    ellipse(x-200,y-30,200,80);

//seeds
    fill(255,220,0);
    noStroke();
    ellipse(x-190,y-27,5,10);
    ellipse(x-180,y-30,5,10);
    ellipse(x-240,y-32,5,10);
    ellipse(x-260,y-37,5,10);
    ellipse(x-290,y-33,5,10);
    ellipse(x-170,y-29,5,10);
    ellipse(x-140,y-31,5,10);
    ellipse(x-130,y-34,5,10);
    ellipse(x-160,y-36,5,10);
    ellipse(x-185,y-42,5,10);
    ellipse(x-163,y-45,5,10);
    ellipse(x-215,y-44,5,10);
    ellipse(x-205,y-43,5,10);
}

function lettuce(x,y,length,width,x2,y2){
    randomMove = (random(0,1));

    if (randomMove > 0.99){
        centerX5 += (random(-50,50));
    }


    fill(0,150,0);
    noStroke();
    ellipse(x-120,y,length,width);
    fill(0,200,0);
    ellipse(x2-120,y2,20,10);

    fill(0,150,0);
    noStroke();
    ellipse(x-140,y+2,length,width);
    fill(0,200,0);
    ellipse(x2-140,y2+2,20,10);

    fill(0,150,0);
    noStroke();
    ellipse(x-160,y-4,length,width);
    fill(0,200,0);
    ellipse(x2-160,y2-4,20,10);

    fill(0,150,0);
    noStroke();
    ellipse(x-190,y,length,width);
    fill(0,200,0);
    ellipse(x2-190,y2,20,10);

    fill(0,150,0);
    noStroke();
    ellipse(x-210,y-4,length,width);
    fill(0,200,0);
    ellipse(x2-210,y2-4,20,10);

    fill(0,150,0);
    noStroke();
    ellipse(x-240,y+1,length,width);
    fill(0,200,0);
    ellipse(x2-240,y2+1,20,10);

    fill(0,150,0);
    noStroke();
    ellipse(x-280,y-2,length,width);
    fill(0,200,0);
    ellipse(x2-280,y2-2,20,10);
}

function ketchup(x,y){
    //shadow
    fill(200,200,200);
    ellipse(x+90,y+95,155,50)

    fill(220,0,0);
    noStroke();
    ellipse(x+90,y+90,150,40);
    //lighting
    fill(255,220,220);
    ellipse(x+70,y+95,80,20);
}

function fries(x,y){
    if (randomMove < 0.01){
        centerY3 += (random(-50,50));
    }

//shadow
    fill(200,200,200);
    ellipse(x+120,y,200,50);
    ellipse(x+220,y+20,200,50);

    stroke(255,220,0);
    strokeWeight(10);
    line(x+100,y-10,x+200,y);
    line(x+110,y-20,x+190,y-10);
    line(x+90,y,x+220,y-30);
    line(x+80,y-20,x+170,y+10);
    line(x+60,y+20,x+190,y-10);
    line(x,y+40,x+130,y+10);
    line(x+10,y-40,x+150,y-45);
    line(x+15,y+35,x+145,y-30);

    line(x+200,y+40,x+300,y+15);
    line(x+210,y,x+290,y);
    line(x+190,y+20,x+320,y-10);
    line(x+180,y,x+270,y+20);
    line(x+160,y+40,x+290,y);
    line(x+175,y+60,x+230,y+30);
    line(x+140,y-50,x+250,y-25);
    line(x+115,y+55,x+245,y-10);
}

function words(){
    fill(255,255,255);
    noStroke();
    textSize(20);
    textFont(pinkyShow);
    text('Nate Tuinstra',1300,685);
    textSize(40);
    text('Burger and Fries',10,50);
}

function imagesAI(sCX,sCY, cPX,cPY){
    image(slothCorvette,sCX,sCY,100,100);
    image(couchPotato,cPX,cPY,100,100);
    image(manTV,600,50,100,100);
}

function imageTimer(){
    //console.log('im working');
    slothCorvetteX += 50;
    if (slothCorvetteX >= 1400){
        slothCorvetteX = 400;
        slothCorvetteY += 100;
    }
    else if (slothCorvetteY >= 700){
        slothCorvetteY = 50;
    }
}

function couchPotatoMove(){
    couchPotatoX += potatoSpeedX;
    couchPotatoY += potatoSpeedY;

    if (couchPotatoX +100 >= 1480 || couchPotatoX <= 0){
        potatoSpeedX *=-1;
    }
    else if (couchPotatoY + 100 >= 725 || couchPotatoY <= 0){
        potatoSpeedY *=-1
    }
}