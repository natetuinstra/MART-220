var animation = [];
var runAnimation = [];
var i = 0;
var f;
var myCharacter;
var characterX = 100;
var characterY = 100;
var speed = 5;
var idleStrings;
var runStrings;
var flipX = false;
var myFood;
var foodArray = [];
var foodAmount = 10;
var score = 0;
var gameTime = 30;
var winTextX = 0;
var winTextY = 0;
var lossTextX = 0;
var lossTextY = 0;
//loads character and passes info into character class
function preload()
{
    /*
    for(var i = 1; i< 16; i++)
        {
            myCharacter = new character("Assets/Images/Idle (" + i + ").png", characterX, characterY);  
            animation.push(myCharacter);
        }
    */
    idleStrings = loadStrings("Assets/idle.txt");
    runStrings = loadStrings("Assets/run.txt");
}

function setup()
{
    createCanvas(1480,725);
    setInterval(updateIndex, 50);
    //setInterval(randomizeFood, 10000);
    setTimeout(gameEnd, gameTime*1000);
    setInterval(countdown, 1000);
    setInterval(randomizeFood, 5000);

    for (let i = 0; i < idleStrings.length; i++) 
    {
        myCharacter = new character(idleStrings[i], characterX, characterY); 
        animation.push(myCharacter);
    
        myCharacter = new character(runStrings[i], characterX, characterY); 
        runAnimation.push(myCharacter);
    }

    //used to generate food
    for (var f = 0; f < foodAmount; f++) 
        {
            myFood = new food(random(0, 1480), random(0, 725));
            foodArray.push(myFood);
        }
}

function draw()
{
    background(0);
   
    //draws the food
    for (let f = 0; f < foodArray.length; f++) 
    {
        foodArray[f].draw();
    }

    //character movement 
    if (keyIsPressed) 
    {
        runAnimation[i].draw();
        if (key == "a") {
            flipX = true
            characterX-= speed;
        }
        if (key == "d") {
            flipX = false
            characterX+= speed;
        }
        if (key == "w") {
            characterY-= speed;
        }
        if (key == "s") {
            characterY+= speed;
        }
        /*
           for (let i = 0; i < 15; i++)
           {
                animation[i].x = characterX;
                animation[i].y = characterY;
           }
        */
        for (let i = 0; i < idleStrings.length; i++) 
        {
            animation[i].flipX = flipX;
            animation[i].x = characterX;
            animation[i].y = characterY;
            runAnimation[i].flipX = flipX;
            runAnimation[i].x = characterX;
            runAnimation[i].y = characterY;
        }
        for (let k = 0; k < foodArray.length; k++)
        {
        if (animation[i].hasCollided(foodArray[k].x, foodArray[k].y, 25, 25)) {
                foodArray.splice(k, 1);
                score ++;
                }
        }
    }
    else {
        animation[i].draw();
    }

    displayCountdown();
    scoreText();
    displayWinLose();
}

function updateIndex()
{
    i++;
    if(i > 14)
    {
        i = 0;
    }  
}

function randomizeFood()
{
    for (var f = 0; f < foodArray.length; f++) 
        {
            foodArray[f].x = random(50,1430);
            foodArray[f].y = random(50,680);
        }
}

function gameEnd()
{
    winTextX = 700;
    winTextY = 300;
    lossTextX = 700;
    lossTextY = 300;
    characterX = 2000;
    characterY = 2000;
}

function displayWinLose()
{
    if(score < foodAmount)
    {
        fill(255,255,255);
        textSize(30);
        text('Loss',lossTextX,lossTextY);
    } 
    else 
    {
        fill(255,255,255);
        textSize(30);
        text('Win',winTextX,winTextY); 
    }

    if(score >= foodAmount)
    {
        fill(255,255,255);
        textSize(30);
        text('Win',winTextX,winTextY);
        winTextX = 700;
        winTextY = 300;
    }

}

function countdown()
{
        gameTime -=1;    
}

function displayCountdown()
{
    fill(255,255,255);
    textSize(30);
    text('Time Left:' + gameTime + 's', 1280, 30);
}

function scoreText()
{
    fill(255,255,255);
    textSize(30);
    text('Score:' + score, 10, 30);
}