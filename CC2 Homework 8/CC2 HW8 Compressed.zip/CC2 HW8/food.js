class food
{
    constructor(x,y,isGood)
    {
        this.x = x;
        this.y = y;
        this.isGood = isGood;
        this.foodPiece = new Sprite(x, y, 30);
    }

    draw(){
        if (this.isGood)
        {
        this.foodPiece.color = "green"
        }
        else
        {
        this.foodPiece.color = "red"
        }
        
        
        
        //fill(this.r,this.g,this.b);
        //circle(this.x, this.y, 25);
        //fill(0);
        //circle(this.x, this.y, 10);
    }
}