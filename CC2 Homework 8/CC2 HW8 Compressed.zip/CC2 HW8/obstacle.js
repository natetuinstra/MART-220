class obstacle
{
    constructor(x,y)
    {
        this.x = x;
        this.y = y;
        this.obstacle = new Sprite(x,y,100,100,'static');
    }

    draw()
    {
        this.obstacle.color = "gray"
    }
}